const { createApp } = Vue

const apiUrl = 'http://localhost:8080'

createApp({
    data() {
        return {
            artikel: [],
            formData: {
                id: null,
                judul: '',
                isi: '',
                status: 0
            },
            showForm: false,
            formTitle: 'Tambah Data',
            statusOptions: [
                { text: 'Draft', value: 0 },
                { text: 'Publish', value: 1 }
            ]
        }
    },
    mounted() {
        this.loadData()
    },
    methods: {
        loadData() {
            axios.get(apiUrl + '/post')
                .then(response => {
                    this.artikel = response.data.artikel
                })
                .catch(error => console.error("Gagal memuat data:", error))
        },
        tambah() {
            this.showForm = true
            this.formTitle = 'Tambah Data'
            this.formData = { id: null, judul: '', isi: '', status: 0 }
        },
        edit(data) {
            this.showForm = true
            this.formTitle = 'Ubah Data'
            this.formData = {
                id: data.id,
                judul: data.judul,
                isi: data.isi,
                status: parseInt(data.status)
            }
        },
        saveData() {
            const payload = {
                judul: this.formData.judul,
                isi: this.formData.isi
            };

            if (this.formData.id) {
                axios.put(apiUrl + '/post/' + this.formData.id, payload)
                    .then(response => {
                        alert('Data artikel berhasil diperbarui!');
                        this.loadData()
                        this.showForm = false
                    })
                    .catch(error => console.error("Gagal mengubah data:", error))
            } else {
                axios.post(apiUrl + '/post', payload)
                    .then(response => {
                        alert('Data artikel berhasil ditambahkan!');
                        this.loadData()
                        this.showForm = false
                    })
                    .catch(error => console.error("Gagal menambah data:", error))
            }

            this.formData = { id: null, judul: '', isi: '', status: 0 };
        },
        hapus(index, id) {
            if (confirm('Yakin menghapus data artikel ini?')) {
                axios.delete(apiUrl + '/post/' + id)
                    .then(response => {
                        alert('Data artikel berhasil dihapus!');
                        this.artikel.splice(index, 1)
                    })
                    .catch(error => console.error("Gagal menghapus data:", error))
            }
        },
        statusText(status) {
            return status == 1 ? 'Publish' : 'Draft'
        }
    }
}).mount('#app')